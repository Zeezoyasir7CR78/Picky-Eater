import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Search, Heart, Clock, Flame, Star, CalendarDays, ShoppingBasket, User, Home, Plus, Minus, Trash2, X, Check, Sparkles, Globe, ChevronLeft, Leaf, UtensilsCrossed, ChefHat, ArrowRight, ArrowLeft, SlidersHorizontal, ShieldCheck, CircleCheck, ShoppingBag, BookOpen } from "lucide-react";

type Lang = "en" | "ar";
type Ingredient = { name: string; nameAr: string; qty: number; unit: string; unitAr: string; cat: string };
type Recipe = { id: string; name: string; nameAr: string; desc: string; descAr: string; category: string; categoryAr: string; time: number; calories: number; difficulty: string; difficultyAr: string; rating: number; reviews: number; tags: string[]; protein: number; carbs: number; fat: number; servings: number; grad: string; letter: string; ingredients: Ingredient[]; steps: string[]; stepsAr: string[] };
type ShopItem = { id: string; name: string; nameAr: string; qty: number; unit: string; cat: string; checked: boolean };

const RECIPES: Recipe[] = [
  { id:"shawarma", name:"Chicken Shawarma Bowl", nameAr:"وعاء شاورما الدجاج", desc:"Smoky shawarma, crunchy pickles and garlic sauce over warm rice.", descAr:"شاورما مدخنة مع مخلل مقرمش وصلصة ثوم على أرز دافئ.", category:"Middle Eastern", categoryAr:"شرقي", time:30, calories:520, difficulty:"Medium", difficultyAr:"متوسط", rating:4.8, reviews:312, tags:["halal","low-carb","gluten-free"], protein:38, carbs:28, fat:26, servings:2, grad:"linear-gradient(135deg,#FF8A3D,#FF4D2E 55%,#C92A0E)", letter:"S", ingredients:[{name:"Chicken thighs",nameAr:"أفخاذ دجاج",qty:400,unit:"g",unitAr:"غ",cat:"Protein"},{name:"Rice",nameAr:"أرز",qty:200,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Yogurt",nameAr:"زبادي",qty:120,unit:"g",unitAr:"غ",cat:"Dairy"},{name:"Cucumber",nameAr:"خيار",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Tomato",nameAr:"طماطم",qty:2,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Garlic sauce",nameAr:"صلصة ثوم",qty:60,unit:"g",unitAr:"غ",cat:"Pantry"}], steps:["Marinate chicken with paprika, cumin, turmeric and lemon for 20 minutes.","Sear chicken until charred, rest 5 minutes, then slice.","Cook rice and chop cucumber and tomato.","Build bowls, add yogurt and garlic sauce."], stepsAr:["تبّلي الدجاج بالبابريكا والكمون والكركم والليمون 20 دقيقة.","حمّري الدجاج حتى يتحمّر، واتركيه 5 دقائق ثم قطّعيه.","اسلقي الأرز وقطّعي الخيار والطماطم.","رتّبي الأطباق وأضيفي الزبادي وصلصة الثوم."] },
  { id:"kabsa", name:"Chicken Kabsa", nameAr:"كبسة الدجاج", desc:"Fragrant Saudi rice with tender chicken, tomato and warm spices.", descAr:"أرز عطري مع دجاج طري وطماطم وبهارات دافئة.", category:"Middle Eastern", categoryAr:"شرقي", time:55, calories:640, difficulty:"Medium", difficultyAr:"متوسط", rating:4.9, reviews:428, tags:["halal","dairy-free","gluten-free"], protein:42, carbs:68, fat:18, servings:4, grad:"linear-gradient(135deg,#FFB23D,#E85D1A)", letter:"K", ingredients:[{name:"Chicken",nameAr:"دجاج",qty:800,unit:"g",unitAr:"غ",cat:"Protein"},{name:"Basmati rice",nameAr:"أرز بسمتي",qty:400,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Tomatoes",nameAr:"طماطم",qty:3,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Carrot",nameAr:"جزر",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Onion",nameAr:"بصل",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Kabsa spice",nameAr:"بهارات كبسة",qty:2,unit:"tbsp",unitAr:"م ك",cat:"Pantry"}], steps:["Brown chicken with onion and spices until golden.","Add blended tomato and carrot, simmer 20 minutes.","Add rice and water, cover and cook on low 25 minutes.","Fluff rice and serve with almonds."], stepsAr:["حمّري الدجاج مع البصل والبهارات حتى يصبح ذهبياً.","أضيفي الطماطم والجزر واتركيه 20 دقيقة.","أضيفي الأرز والماء وغطّيه على نار هادئة 25 دقيقة.","قلّبي الأرز وقدّميه مع اللوز."] },
  { id:"hummus", name:"Hummus & Grilled Veg", nameAr:"حمص وخضار مشوية", desc:"Silky hummus, charred peppers, zucchini and a lemon drizzle.", descAr:"حمص ناعم مع فلفل وكوسا مشوية وقطرات ليمون.", category:"Middle Eastern", categoryAr:"شرقي", time:15, calories:320, difficulty:"Easy", difficultyAr:"سهل", rating:4.7, reviews:198, tags:["vegetarian","vegan","gluten-free","halal","dairy-free"], protein:11, carbs:32, fat:16, servings:2, grad:"linear-gradient(135deg,#A8D5A2,#4C9A5A)", letter:"H", ingredients:[{name:"Chickpeas",nameAr:"حمص",qty:400,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Tahini",nameAr:"طحينة",qty:60,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Zucchini",nameAr:"كوسا",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Pepper",nameAr:"فلفل",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Lemon",nameAr:"ليمون",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Pita",nameAr:"خبز",qty:2,unit:"pc",unitAr:"حبة",cat:"Pantry"}], steps:["Blend chickpeas, tahini, lemon and ice water until silky.","Grill zucchini and pepper with olive oil and salt.","Spoon hummus, pile veg on top.","Finish with paprika, olive oil and warm pita."], stepsAr:["اخلطي الحمص والطحينة والليمون وماء مثلج حتى يصبح ناعماً.","اشوي الكوسا والفلفل بزيت الزيتون والملح.","ضعي الحمص ثم الخضار فوقه.","أنهي بالبابريكا وزيت الزيتون وخبز دافئ."] },
  { id:"salmon", name:"Salmon with Quinoa", nameAr:"سلمون مع كينوا", desc:"Crisp salmon, fluffy quinoa and a bright herb salad.", descAr:"سلمون مقرمش مع كينوا وسلطة أعشاب منعشة.", category:"International", categoryAr:"عالمي", time:25, calories:480, difficulty:"Medium", difficultyAr:"متوسط", rating:4.8, reviews:265, tags:["gluten-free","dairy-free","halal","low-carb"], protein:36, carbs:32, fat:22, servings:2, grad:"linear-gradient(135deg,#FF9A7A,#E86A4A)", letter:"Sa", ingredients:[{name:"Salmon fillet",nameAr:"فيليه سلمون",qty:300,unit:"g",unitAr:"غ",cat:"Protein"},{name:"Quinoa",nameAr:"كينوا",qty:160,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Spinach",nameAr:"سبانخ",qty:80,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Lemon",nameAr:"ليمون",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Cucumber",nameAr:"خيار",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Dill",nameAr:"شبت",qty:10,unit:"g",unitAr:"غ",cat:"Produce"}], steps:["Cook quinoa and let it steam 5 minutes.","Sear salmon skin-side down until crisp, flip 2 minutes.","Toss spinach, cucumber, dill and lemon.","Serve salmon over quinoa with salad."], stepsAr:["اسلقي الكينوا واتركيها تبخّر 5 دقائق.","حمّري السلمون من جهة الجلد حتى يقرمش ثم اقلبيه دقيقتين.","قلّبي السبانخ والخيار والشبت والليمون.","قدّمي السلمون فوق الكينوا مع السلطة."] },
  { id:"avocado", name:"Avocado Toast", nameAr:"توست الأفوكادو", desc:"Smashed avocado, chili crunch, egg and toasted sourdough.", descAr:"أفوكادو مهروس مع بيض وتوست محمّص.", category:"Breakfast", categoryAr:"فطور", time:10, calories:290, difficulty:"Easy", difficultyAr:"سهل", rating:4.6, reviews:341, tags:["vegetarian","halal"], protein:11, carbs:26, fat:17, servings:1, grad:"linear-gradient(135deg,#B8E39A,#4A9A3A)", letter:"A", ingredients:[{name:"Avocado",nameAr:"أفوكادو",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Sourdough",nameAr:"خبز",qty:2,unit:"pc",unitAr:"حبة",cat:"Pantry"},{name:"Eggs",nameAr:"بيض",qty:2,unit:"pc",unitAr:"حبة",cat:"Protein"},{name:"Cherry tomato",nameAr:"طماطم كرزية",qty:120,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Lemon",nameAr:"ليمون",qty:0.5,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Chili flakes",nameAr:"رقائق فلفل",qty:1,unit:"tsp",unitAr:"م ص",cat:"Pantry"}], steps:["Toast sourdough until golden and crisp.","Smash avocado with lemon and salt.","Fry eggs to your liking.","Top toast, add tomato and chili flakes."], stepsAr:["حمّصي الخبز حتى يصبح ذهبياً.","اهرسي الأفوكادو مع الليمون والملح.","اقلِ البيض كما تحبين.","ضعي المزيج على الخبز وأضيفي الطماطم والفلفل."] },
  { id:"lentil", name:"Lentil Soup", nameAr:"شوربة العدس", desc:"Golden lentils, cumin and lemon — cozy, light and filling.", descAr:"عدس ذهبي مع كمون وليمون — دافئ وخفيف.", category:"Middle Eastern", categoryAr:"شرقي", time:35, calories:280, difficulty:"Easy", difficultyAr:"سهل", rating:4.8, reviews:512, tags:["vegetarian","vegan","gluten-free","halal","dairy-free"], protein:14, carbs:38, fat:7, servings:4, grad:"linear-gradient(135deg,#FFC65A,#F08A1A)", letter:"L", ingredients:[{name:"Red lentils",nameAr:"عدس أحمر",qty:300,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Onion",nameAr:"بصل",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Carrot",nameAr:"جزر",qty:2,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Cumin",nameAr:"كمون",qty:1,unit:"tsp",unitAr:"م ص",cat:"Pantry"},{name:"Lemon",nameAr:"ليمون",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Olive oil",nameAr:"زيت زيتون",qty:2,unit:"tbsp",unitAr:"م ك",cat:"Pantry"}], steps:["Soften onion and carrot in olive oil.","Add lentils, cumin and water. Simmer 25 minutes.","Blend until smooth and creamy.","Serve with lemon and a drizzle of oil."], stepsAr:["قلّبي البصل والجزر بزيت الزيتون.","أضيفي العدس والكمون والماء واتركيه 25 دقيقة.","اخلطي حتى يصبح ناعماً.","قدّميه مع الليمون وقطرات زيت."] },
  { id:"halloumi", name:"Grilled Halloumi Salad", nameAr:"سلطة حلوم مشوي", desc:"Golden halloumi, watermelon, mint and honey-lime dressing.", descAr:"حلوم ذهبي مع بطيخ ونعناع وصلصة عسل وليمون.", category:"Healthy", categoryAr:"صحي", time:15, calories:360, difficulty:"Easy", difficultyAr:"سهل", rating:4.7, reviews:176, tags:["vegetarian","gluten-free","halal"], protein:18, carbs:18, fat:24, servings:2, grad:"linear-gradient(135deg,#FFE27A,#E8A800)", letter:"Hl", ingredients:[{name:"Halloumi",nameAr:"حلوم",qty:200,unit:"g",unitAr:"غ",cat:"Dairy"},{name:"Watermelon",nameAr:"بطيخ",qty:250,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Mint",nameAr:"نعناع",qty:12,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Rocket",nameAr:"جرجير",qty:60,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Honey",nameAr:"عسل",qty:1,unit:"tbsp",unitAr:"م ك",cat:"Pantry"},{name:"Lime",nameAr:"ليمون أخضر",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"}], steps:["Slice and grill halloumi until golden.","Cube watermelon and tear mint.","Whisk honey, lime and olive oil.","Toss rocket, top with halloumi and watermelon."], stepsAr:["قطّعي الحلوم واشويه حتى يصبح ذهبياً.","قطّعي البطيخ وقطّعي النعناع.","اخلطي العسل والليمون وزيت الزيتون.","قلّبي الجرجير وضعي الحلوم والبطيخ فوقه."] },
  { id:"pasta", name:"Pasta Alfredo (Light)", nameAr:"باستا ألفريدو خفيفة", desc:"Creamy light Alfredo with mushrooms, garlic and parmesan.", descAr:"ألفريدو خفيفة كريمية مع فطر وثوم وبارميزان.", category:"International", categoryAr:"عالمي", time:25, calories:520, difficulty:"Easy", difficultyAr:"سهل", rating:4.5, reviews:289, tags:["vegetarian","halal"], protein:18, carbs:62, fat:18, servings:2, grad:"linear-gradient(135deg,#FFD8B0,#E8A05A)", letter:"P", ingredients:[{name:"Pasta",nameAr:"باستا",qty:250,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Mushrooms",nameAr:"فطر",qty:200,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Milk",nameAr:"حليب",qty:250,unit:"ml",unitAr:"مل",cat:"Dairy"},{name:"Parmesan",nameAr:"بارميزان",qty:50,unit:"g",unitAr:"غ",cat:"Dairy"},{name:"Garlic",nameAr:"ثوم",qty:3,unit:"cloves",unitAr:"فص",cat:"Produce"},{name:"Parsley",nameAr:"بقدونس",qty:10,unit:"g",unitAr:"غ",cat:"Produce"}], steps:["Boil pasta until al dente, save a cup of pasta water.","Sauté mushrooms and garlic.","Add milk, simmer, stir in parmesan.","Toss pasta, loosen with pasta water."], stepsAr:["اسلقي الباستا واحتفظي بكوب من مائها.","قلّبي الفطر والثوم.","أضيفي الحليب واتركيه يغلي ثم البارميزان.","قلّبي الباستا وخفّفيها بماء السلق."] },
  { id:"shakshuka", name:"Shakshuka", nameAr:"شكشوكة", desc:"Baked eggs in rich tomato-pepper sauce with feta and herbs.", descAr:"بيض مخبوز في صلصة طماطم وفلفل مع جبنة واعشاب.", category:"Breakfast", categoryAr:"فطور", time:20, calories:310, difficulty:"Easy", difficultyAr:"سهل", rating:4.9, reviews:623, tags:["vegetarian","gluten-free","halal"], protein:15, carbs:16, fat:20, servings:2, grad:"linear-gradient(135deg,#FF7A5A,#D62F1A)", letter:"Sh", ingredients:[{name:"Eggs",nameAr:"بيض",qty:4,unit:"pc",unitAr:"حبة",cat:"Protein"},{name:"Tomatoes",nameAr:"طماطم",qty:4,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Pepper",nameAr:"فلفل",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Feta",nameAr:"جبنة فيتا",qty:80,unit:"g",unitAr:"غ",cat:"Dairy"},{name:"Onion",nameAr:"بصل",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Cumin",nameAr:"كمون",qty:1,unit:"tsp",unitAr:"م ص",cat:"Pantry"}], steps:["Soften onion and pepper, add tomato and cumin.","Simmer sauce 10 minutes until thick.","Make wells, crack in eggs, cover 5 minutes.","Top with feta and herbs, serve with bread."], stepsAr:["قلّبي البصل والفلفل ثم أضيفي الطماطم والكمون.","اتركي الصلصة 10 دقائق حتى تتماسك.","اعملي فراغات واكسري البيض وغطّيه 5 دقائق.","أضيفي الفيتا والأعشاب وقدّميها مع الخبز."] },
  { id:"curry", name:"Chicken Curry", nameAr:"كاري الدجاج", desc:"Coconut chicken curry with ginger, spices and basmati.", descAr:"كاري دجاج بجوز الهند والزنجبيل والبهارات مع أرز بسمتي.", category:"International", categoryAr:"عالمي", time:40, calories:540, difficulty:"Medium", difficultyAr:"متوسط", rating:4.7, reviews:354, tags:["gluten-free","dairy-free","halal"], protein:36, carbs:42, fat:24, servings:3, grad:"linear-gradient(135deg,#FFB84D,#E85D00)", letter:"C", ingredients:[{name:"Chicken",nameAr:"دجاج",qty:600,unit:"g",unitAr:"غ",cat:"Protein"},{name:"Coconut milk",nameAr:"حليب جوز الهند",qty:400,unit:"ml",unitAr:"مل",cat:"Pantry"},{name:"Onion",nameAr:"بصل",qty:1,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Ginger",nameAr:"زنجبيل",qty:20,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Curry powder",nameAr:"بهارات كاري",qty:2,unit:"tbsp",unitAr:"م ك",cat:"Pantry"},{name:"Rice",nameAr:"أرز",qty:250,unit:"g",unitAr:"غ",cat:"Pantry"}], steps:["Brown chicken and set aside.","Soften onion, ginger and curry powder.","Add coconut milk, return chicken, simmer 20 minutes.","Serve over rice with coriander."], stepsAr:["حمّري الدجاج واتركيه جانباً.","قلّبي البصل والزنجبيل والكاري.","أضيفي حليب جوز الهند والدجاج واتركيه 20 دقيقة.","قدّميه مع الأرز والكزبرة."] },
  { id:"greek", name:"Greek Salad", nameAr:"سلطة يونانية", desc:"Crunchy cucumber, olives, feta and oregano with lemon oil.", descAr:"خيار مقرمش وزيتون وفيتا وزعتر مع زيت ليمون.", category:"Healthy", categoryAr:"صحي", time:10, calories:220, difficulty:"Easy", difficultyAr:"سهل", rating:4.6, reviews:203, tags:["vegetarian","gluten-free","halal"], protein:7, carbs:10, fat:17, servings:2, grad:"linear-gradient(135deg,#A8E6A1,#2E9E5B)", letter:"G", ingredients:[{name:"Cucumber",nameAr:"خيار",qty:2,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Tomatoes",nameAr:"طماطم",qty:3,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Feta",nameAr:"فيتا",qty:120,unit:"g",unitAr:"غ",cat:"Dairy"},{name:"Olives",nameAr:"زيتون",qty:80,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Red onion",nameAr:"بصل أحمر",qty:0.5,unit:"pc",unitAr:"حبة",cat:"Produce"},{name:"Oregano",nameAr:"زعتر",qty:1,unit:"tsp",unitAr:"م ص",cat:"Pantry"}], steps:["Chop cucumber, tomato and onion.","Add olives and feta chunks.","Whisk lemon, oil and oregano.","Toss gently and serve chilled."], stepsAr:["قطّعي الخيار والطماطم والبصل.","أضيفي الزيتون والفيتا.","اخلطي الليمون والزيت والزعتر.","قلّبي بلطف وقدّميها باردة."] },
  { id:"oats", name:"Overnight Oats", nameAr:"شوفان ليلي", desc:"Creamy oats, berries, chia and honey — ready from the fridge.", descAr:"شوفان كريمي مع توت وبذور شيا وعسل — جاهز من الثلاجة.", category:"Breakfast", categoryAr:"فطور", time:5, calories:340, difficulty:"Easy", difficultyAr:"سهل", rating:4.7, reviews:412, tags:["vegetarian","halal"], protein:12, carbs:52, fat:10, servings:1, grad:"linear-gradient(135deg,#C9A8FF,#7A4DE0)", letter:"O", ingredients:[{name:"Oats",nameAr:"شوفان",qty:80,unit:"g",unitAr:"غ",cat:"Pantry"},{name:"Milk",nameAr:"حليب",qty:180,unit:"ml",unitAr:"مل",cat:"Dairy"},{name:"Yogurt",nameAr:"زبادي",qty:100,unit:"g",unitAr:"غ",cat:"Dairy"},{name:"Berries",nameAr:"توت",qty:120,unit:"g",unitAr:"غ",cat:"Produce"},{name:"Chia seeds",nameAr:"بذور شيا",qty:1,unit:"tbsp",unitAr:"م ك",cat:"Pantry"},{name:"Honey",nameAr:"عسل",qty:1,unit:"tsp",unitAr:"م ص",cat:"Pantry"}], steps:["Mix oats, milk, yogurt and chia.","Stir in honey and half the berries.","Chill overnight in a jar.","Top with remaining berries and serve."], stepsAr:["اخلطي الشوفان والحليب والزبادي والشيا.","أضيفي العسل ونصف التوت.","برّديه طوال الليل في برطمان.","زيّنيه بباقي التوت وقدّميه."] },
];

const DICT: Record<Lang, any> = {
  en:{ tagline:"Eat what you love, your way.", start:"Start Exploring", how:"How it works", f1:"Pick your tastes", f2:"Plan your week", f3:"Shop in one tap", search:"Search recipes, ingredients…", discover:"Discover", forYou:"Made for you", aiTitle:"AI Picks For You", aiSub:"Based on your tastes, allergies and disliked foods.", aiBtn:"Get AI Suggestions", aiDone:"Your personalized picks", aiHint:"Tap Get AI Suggestions to refresh your picks.", categories:"Categories", all:"All", recipes:"Recipes", planner:"Planner", shopping:"Shopping", favorites:"Favorites", profile:"Profile", home:"Home", favEmpty:"No favorites yet", favEmptySub:"Tap the heart on any recipe to save it here.", ingredients:"Ingredients", steps:"How to cook", nutrition:"Nutrition", servings:"Servings", addShop:"Add to Shopping List", addPlan:"Add to Planner", addedShop:"Added to shopping list", planTitle:"Weekly Meal Planner", clearWeek:"Clear week", dayCal:"Day total", breakfast:"Breakfast", lunch:"Lunch", dinner:"Dinner", pickRecipe:"Choose a recipe", remove:"Remove", shopTitle:"Shopping List", addCustom:"Add custom item", clearChecked:"Clear checked", checked:"checked", emptyShop:"Your list is empty", emptyShopSub:"Add from a recipe or planner to get started.", prefs:"Dietary Preferences", allergies:"Allergies", disliked:"Disliked ingredients", calorieGoal:"Daily calorie goal", language:"Language", saveNote:"Your choices save automatically.", emptyPlanner:"No recipe yet", tapToAdd:"Tap to add a recipe", profileSub:"Make Picky Eater truly yours.", weekPlan:"Plan this week", items:"items", kcal:"kcal", min:"min", perServing:"per serving", protein:"Protein", carbs:"Carbs", fat:"Fat", qty:"Qty", category:"Category", add:"Add", cancel:"Cancel", close:"Close", chooseDay:"Choose day & meal", saved:"Saved", loading:"Loading your saved meals…", pickSlot:"Pick a slot for this recipe", total:"Total", back:"Back", difficulty:"Difficulty", rating:"Rating", time:"Time", calories:"Calories", searchNo:"No recipes match your search.", allRecipes:"All recipes", personalized:"Personalized", quick:"Quick & easy", middle:"Middle Eastern", intl:"International", healthy:"Healthy", breakfastCat:"Breakfast", dinnerCat:"Dinner", produce:"Produce", pantry:"Pantry", dairy:"Dairy", proteinCat:"Protein", other:"Other", itemName:"Item name", needName:"Type an item name first.", plannerAdded:"Added to planner", selectRecipe:"Select a recipe", },
  ar:{ tagline:"كُل ما تحب، بطريقتك.", start:"ابدأ الاستكشاف", how:"كيف يعمل التطبيق؟", f1:"اختر ذوقك", f2:"خطط لأسبوعك", f3:"تسوّق بضغطة واحدة", search:"ابحث عن وصفة أو مكوّن…", discover:"اكتشف", forYou:"صُمم من أجلك", aiTitle:"اختيارات الذكاء الاصطناعي لك", aiSub:"بناءً على ذوقك وحساسيتك والأطعمة التي لا تحبها.", aiBtn:"احصل على اقتراحات ذكية", aiDone:"اختياراتك المخصصة", aiHint:"اضغط على زر الاقتراحات لتحديث اختياراتك.", categories:"التصنيفات", all:"الكل", recipes:"الوصفات", planner:"المخطط", shopping:"التسوق", favorites:"المفضلة", profile:"حسابي", home:"الرئيسية", favEmpty:"لا توجد مفضلة بعد", favEmptySub:"اضغط على القلب في أي وصفة لحفظها هنا.", ingredients:"المكونات", steps:"طريقة التحضير", nutrition:"القيمة الغذائية", servings:"عدد الحصص", addShop:"أضف لقائمة التسوق", addPlan:"أضف للمخطط", addedShop:"تمت الإضافة لقائمة التسوق", planTitle:"مخطط وجبات الأسبوع", clearWeek:"مسح الأسبوع", dayCal:"إجمالي اليوم", breakfast:"الفطور", lunch:"الغداء", dinner:"العشاء", pickRecipe:"اختر وصفة", remove:"إزالة", shopTitle:"قائمة التسوق", addCustom:"أضف عنصراً مخصصاً", clearChecked:"مسح المحدد", checked:"محدد", emptyShop:"قائمتك فارغة", emptyShopSub:"أضف من وصفة أو مخطط للبدء.", prefs:"التفضيلات الغذائية", allergies:"الحساسية", disliked:"مكونات لا تحبها", calorieGoal:"هدف السعرات اليومي", language:"اللغة", saveNote:"يتم حفظ اختياراتك تلقائياً.", emptyPlanner:"لا توجد وصفة بعد", tapToAdd:"اضغط لإضافة وصفة", profileSub:"اجعل بيكي إيتر مناسباً لك تماماً.", weekPlan:"خطط لهذا الأسبوع", items:"عنصر", kcal:"سعرة", min:"دقيقة", perServing:"لكل حصة", protein:"بروتين", carbs:"كربوهيدرات", fat:"دهون", qty:"الكمية", category:"الفئة", add:"إضافة", cancel:"إلغاء", close:"إغلاق", chooseDay:"اختر اليوم والوجبة", saved:"تم الحفظ", loading:"جارٍ تحميل وجباتك المحفوظة…", pickSlot:"اختر مكان هذه الوصفة", total:"الإجمالي", back:"رجوع", difficulty:"الصعوبة", rating:"التقييم", time:"الوقت", calories:"السعرات", searchNo:"لا توجد وصفات مطابقة لبحثك.", allRecipes:"كل الوصفات", personalized:"مخصص لك", quick:"سريع وسهل", middle:"شرقي", intl:"عالمي", healthy:"صحي", breakfastCat:"فطور", dinnerCat:"عشاء", produce:"خضار وفواكه", pantry:"مؤونة", dairy:"ألبان", proteinCat:"بروتين", other:"أخرى", itemName:"اسم العنصر", needName:"اكتب اسم العنصر أولاً.", plannerAdded:"تمت الإضافة للمخطط", selectRecipe:"اختر وصفة", }
};

const DAYS_EN = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const DAYS_AR = ["الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت","الأحد"];
const DIET_OPTS = [{id:"vegetarian",en:"Vegetarian",ar:"نباتي"},{id:"vegan",en:"Vegan",ar:"فيغان"},{id:"gluten-free",en:"Gluten-Free",ar:"خالٍ من الغلوتين"},{id:"halal",en:"Halal",ar:"حلال"},{id:"low-carb",en:"Low-Carb",ar:"قليل الكربوهيدرات"},{id:"dairy-free",en:"Dairy-Free",ar:"خالٍ من الألبان"}];
const ALLERGY_OPTS = [{id:"nuts",en:"Nuts",ar:"مكسرات"},{id:"gluten",en:"Gluten",ar:"غلوتين"},{id:"dairy",en:"Dairy",ar:"ألبان"},{id:"seafood",en:"Seafood",ar:"مأكولات بحرية"}];
const CATS = [{id:"All",en:"All",ar:"الكل"},{id:"Middle Eastern",en:"Middle Eastern",ar:"شرقي"},{id:"International",en:"International",ar:"عالمي"},{id:"Breakfast",en:"Breakfast",ar:"فطور"},{id:"Healthy",en:"Healthy",ar:"صحي"}];

async function callApi(action:string, args:any){
  const res = await fetch("actions",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action,args})});
  const json = await res.json().catch(()=>({}));
  if(!res.ok || json.error) throw new Error(json.error || "Request failed");
  return json.data;
}

export default function App(){
  const [lang,setLang] = useState<Lang>("en");
  const t = DICT[lang];
  const [started,setStarted] = useState(false);
  const [tab,setTab] = useState("home");
  const [search,setSearch] = useState("");
  const [dietFilter,setDietFilter] = useState("all");
  const [category,setCategory] = useState("All");
  const [selectedId,setSelectedId] = useState<string|null>(null);
  const [servings,setServings] = useState(2);
  const [favorites,setFavorites] = useState<string[]>([]);
  const [planner,setPlanner] = useState<Record<string,string>>({});
  const [shopping,setShopping] = useState<ShopItem[]>([]);
  const [dietary,setDietary] = useState<string[]>(["halal"]);
  const [allergies,setAllergies] = useState<string[]>([]);
  const [disliked,setDisliked] = useState<string[]>(["mushrooms"]);
  const [calorieGoal,setCalorieGoal] = useState(2000);
  const [aiPicks,setAiPicks] = useState<string[]|null>(null);
  const [aiReasons,setAiReasons] = useState<Record<string,string>>({});
  const [plannerDayIdx,setPlannerDayIdx] = useState(0);
  const [pickerSlot,setPickerSlot] = useState<string|null>(null);
  const [detailPlannerOpen,setDetailPlannerOpen] = useState(false);
  const [detailDay,setDetailDay] = useState(0);
  const [detailSlot,setDetailSlot] = useState("lunch");
  const [customName,setCustomName] = useState("");
  const [customCat,setCustomCat] = useState("Produce");
  const [newDisliked,setNewDisliked] = useState("");
  const [toast,setToast] = useState("");
  const [loaded,setLoaded] = useState(false);
  const [saveNote,setSaveNote] = useState("");
  const idsRef = useRef<Record<string,string>>({});
  const [recordIds,setRecordIds] = useState<Record<string,string>>({});
  useEffect(()=>{ idsRef.current = recordIds; },[recordIds]);

  const persist = useCallback(async (collection:string, value:any)=>{
    try{
      const existing = idsRef.current[collection];
      if(existing){ await callApi("records.replace",{collection,id:existing,value}); }
      else { const created:any = await callApi("records.create",{collection,value}); if(created?.id){ const next={...idsRef.current,[collection]:created.id}; idsRef.current=next; setRecordIds(next);} }
      setSaveNote(DICT[lang]?.saved || "Saved");
    }catch{ /* offline preview: keep local state */ }
  },[lang]);

  useEffect(()=>{
    (async()=>{
      try{
        const cols = ["picky_settings","picky_favorites","picky_planner","picky_shopping"];
        for(const c of cols){
          const data:any = await callApi("records.list",{collection:c});
          const rec = data?.records?.[0];
          if(rec){
            idsRef.current={...idsRef.current,[c]:rec.id}; setRecordIds({...idsRef.current});
            if(c==="picky_settings"){ const v=rec.value||{}; if(v.lang) setLang(v.lang); if(Array.isArray(v.dietary)) setDietary(v.dietary); if(Array.isArray(v.allergies)) setAllergies(v.allergies); if(Array.isArray(v.disliked)) setDisliked(v.disliked); if(v.calorieGoal) setCalorieGoal(v.calorieGoal); }
            if(c==="picky_favorites" && Array.isArray(rec.value?.ids)) setFavorites(rec.value.ids);
            if(c==="picky_planner" && rec.value?.map) setPlanner(rec.value.map);
            if(c==="picky_shopping" && Array.isArray(rec.value?.items)) setShopping(rec.value.items);
          }
        }
      }catch{}
      setLoaded(true);
    })();
  },[]);

  useEffect(()=>{ if(loaded) persist("picky_settings",{lang,dietary,allergies,disliked,calorieGoal}); },[lang,dietary,allergies,disliked,calorieGoal,loaded]);
  useEffect(()=>{ if(loaded) persist("picky_favorites",{ids:favorites}); },[favorites,loaded]);
  useEffect(()=>{ if(loaded) persist("picky_planner",{map:planner}); },[planner,loaded]);
  useEffect(()=>{ if(loaded) persist("picky_shopping",{items:shopping}); },[shopping,loaded]);

  const showToast = (msg:string)=>{ setToast(msg); setTimeout(()=>setToast(""),2200); };
  const recipeById = (id:string)=> RECIPES.find(r=>r.id===id);
  const selected = selectedId ? recipeById(selectedId) : undefined;

  const filtered = useMemo(()=>{
    return RECIPES.filter(r=>{
      const q = search.trim().toLowerCase();
      const matchesQ = !q || r.name.toLowerCase().includes(q) || r.nameAr.includes(search.trim()) || r.ingredients.some(i=>i.name.toLowerCase().includes(q));
      const matchesDiet = dietFilter==="all" || r.tags.includes(dietFilter);
      const matchesCat = category==="All" || r.category===category;
      const dislikedHit = disliked.some(d=> r.name.toLowerCase().includes(d.toLowerCase()) || r.ingredients.some(i=>i.name.toLowerCase().includes(d.toLowerCase())));
      return matchesQ && matchesDiet && matchesCat && !dislikedHit;
    });
  },[search,dietFilter,category,disliked]);

  const toggleFav = (id:string)=> setFavorites(prev=> prev.includes(id)? prev.filter(x=>x!==id): [...prev,id]);
  const toggleList = (list:string[], val:string, setter:(v:string[])=>void)=> setter(list.includes(val)? list.filter(x=>x!==val): [...list,val]);

  const generateAI = ()=>{
    const scored = RECIPES.map(r=>{
      let score = r.rating*10;
      if(dietary.length) score += r.tags.filter(tag=>dietary.includes(tag)).length*18;
      if(dietary.includes("vegetarian") && r.tags.includes("vegetarian")) score+=10;
      if(allergies.includes("dairy") && r.tags.includes("dairy-free")) score+=8;
      if(allergies.includes("gluten") && r.tags.includes("gluten-free")) score+=8;
      const bad = disliked.some(d=> r.ingredients.some(i=>i.name.toLowerCase().includes(d.toLowerCase())));
      if(bad) score-=100;
      if(r.calories<=calorieGoal/3) score+=4;
      return {r,score};
    }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,3);
    setAiPicks(scored.map(x=>x.r.id));
    const reasons:Record<string,string>={};
    scored.forEach(({r})=>{
      const matched = r.tags.filter(tag=>dietary.includes(tag));
      reasons[r.id]= lang==="ar" ? `يتناسب مع ${matched.length? matched.map(m=>DIET_OPTS.find(d=>d.id===m)?.ar||m).join(" و "): "ذوقك"} • ${r.calories} سعرة • تقييم ${r.rating}` : `Matches ${matched.length? matched.join(" + "): "your taste"} • ${r.calories} kcal • Rated ${r.rating}`;
    });
    setAiReasons(reasons);
  };

  const addToShopping = (recipe:Recipe, serves:number)=>{
    const scale = serves / recipe.servings;
    setShopping(prev=>{
      const next=[...prev];
      recipe.ingredients.forEach(ing=>{
        const name = lang==="ar"? ing.nameAr: ing.name;
        const idx = next.findIndex(x=>x.name.toLowerCase()===ing.name.toLowerCase() && !x.checked);
        const qty = Math.round(ing.qty*scale*10)/10;
        if(idx>=0) next[idx]={...next[idx], qty: Math.round((next[idx].qty+qty)*10)/10};
        else next.push({id:`${recipe.id}-${ing.name}-${Date.now()}-${Math.random()}`, name: ing.name, nameAr: ing.nameAr, qty, unit: lang==="ar"? ing.unitAr: ing.unit, cat: ing.cat, checked:false});
      });
      return next;
    });
    showToast(t.addedShop);
  };
  const addToPlanner = (recipeId:string, dayIdx:number, slot:string)=>{
    const key=`${dayIdx}-${slot}`;
    setPlanner(prev=>({...prev,[key]:recipeId}));
    showToast(t.plannerAdded);
  };
  const openRecipe = (id:string)=>{ setSelectedId(id); const r=recipeById(id); setServings(r? r.servings:2); };

  const days = lang==="ar"? DAYS_AR: DAYS_EN;
  const slots = [{id:"breakfast",label:t.breakfast},{id:"lunch",label:t.lunch},{id:"dinner",label:t.dinner}];
  const dayCalories = (dayIdx:number)=> slots.reduce((sum,s)=>{ const rid=planner[`${dayIdx}-${s.id}`]; const r=rid? recipeById(rid):undefined; return sum+(r?.calories||0); },0);
  const groupedShopping = useMemo(()=>{
    const groups:Record<string,ShopItem[]>={};
    shopping.forEach(it=>{ (groups[it.cat]=groups[it.cat]||[]).push(it); });
    return groups;
  },[shopping]);
  const checkedCount = shopping.filter(i=>i.checked).length;

  if(!started){
    return (
      <div className="min-h-screen bg-[#EADFD6] flex justify-center" dir={lang==="ar"?"rtl":"ltr"}>
        <div className="w-full max-w-[430px] bg-[#FFF8F0] min-h-screen flex flex-col overflow-x-clip">
          <div className="px-6 pt-8 pb-6 flex items-center justify-between">
            <div className="flex items-center gap-2"><div className="w-10 h-10 rounded-2xl bg-[#FF4D2E] grid place-items-center text-white font-black text-xl">P</div><div><p className="font-black leading-none text-[18px]">Picky Eater</p><p className="text-[13px] text-[#7A6E66]">بيكي إيتر</p></div></div>
            <button onClick={()=>setLang(lang==="en"?"ar":"en")} className="flex items-center gap-1.5 bg-white border border-[#F0DDD3] px-3 py-2 rounded-full text-[13px] font-bold shadow-sm"><Globe size={15}/>{lang==="en"?"عربي":"EN"}</button>
          </div>
          <div className="px-6">
            <div className="rounded-[28px] p-6 text-white relative overflow-hidden" style={{background:"linear-gradient(135deg,#FF4D2E,#FF8A3D)"}}>
              <p className="text-[13px] bg-white/20 inline-block px-3 py-1 rounded-full font-bold">{lang==="ar"?"أهلاً بك في بيكي إيتر":"WELCOME TO PICKY EATER"}</p>
              <h1 className="text-[38px] leading-[1.05] font-black mt-4">{lang==="ar"?"كُل ما تحب، بطريقتك." : <>Eat what you<br/>love, <span className="text-[#FFE27A]">your way.</span></>}</h1>
              <p className="mt-3 text-white/90 text-[15px] leading-relaxed">{lang==="ar"?"وصفات تناسب ذوقك، مخطط أسبوعي، وقائمة تسوق ذكية — كلها في مكان واحد.":"Recipes that fit your taste, a weekly planner and a smart shopping list — all in one place."}</p>
              <div className="flex gap-2 mt-5"><span className="bg-white text-[#1E1B18] px-3 py-1.5 rounded-full text-[12px] font-bold">12 {lang==="ar"?"وصفة":"recipes"}</span><span className="bg-black/20 px-3 py-1.5 rounded-full text-[12px] font-bold">EN • عربي</span><span className="bg-black/20 px-3 py-1.5 rounded-full text-[12px] font-bold">AI Picks</span></div>
              <div className="absolute -bottom-6 -end-6 w-32 h-32 rounded-full bg-white/15" /><div className="absolute top-6 end-10 w-10 h-10 rounded-full bg-white/20" />
            </div>
          </div>
          <div className="px-6 mt-6 space-y-3">
            {[{icon:<UtensilsCrossed size={20}/>,title:t.f1,sub:lang==="ar"?"أخبرنا بما تحب وما لا تحب.":"Tell us what you love and what you skip."},{icon:<CalendarDays size={20}/>,title:t.f2,sub:lang==="ar"?"رتّب الفطور والغداء والعشاء.":"Arrange breakfast, lunch and dinner."},{icon:<ShoppingBasket size={20}/>,title:t.f3,sub:lang==="ar"?"تُبنى قائمتك تلقائياً من وصفاتك.":"Your list builds itself from your recipes."}].map((f,i)=>(
              <div key={i} className="bg-white rounded-[20px] p-4 flex gap-3 items-center shadow-sm border border-[#FFF0E8]"><div className="w-11 h-11 rounded-2xl bg-[#E4F6EC] text-[#1F9D5E] grid place-items-center shrink-0">{f.icon}</div><div><p className="font-extrabold">{f.title}</p><p className="text-[13px] text-[#7A6E66]">{f.sub}</p></div></div>
            ))}
          </div>
          <div className="mt-auto px-6 pb-8 pt-6">
            <button onClick={()=>setStarted(true)} className="w-full bg-[#1E1B18] text-white py-4 rounded-full font-extrabold text-[16px] flex items-center justify-center gap-2">{t.start} {lang==="ar"? <ArrowLeft size={18}/> : <ArrowRight size={18}/>}</button>
            <p className="text-center text-[12px] text-[#7A6E66] mt-3">{lang==="ar"?"بدون حساب • يعمل على أندرويد وآيفون":"No account needed • Works on Android & iPhone"}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div data-safe-area-inset-root style={{boxSizing:"border-box",paddingTop:"var(--safe-area-inset-top)"}} className="min-h-screen bg-[#EADFD6] flex justify-center" dir={lang==="ar"?"rtl":"ltr"}>
      <div className="w-full max-w-[430px] bg-[#FFF8F0] min-h-screen flex flex-col relative overflow-x-clip">
        {/* TOP BAR */}
        <header data-safe-area-sticky-top style={{top:"var(--safe-area-inset-top)"}} className="sticky top-0 z-30 bg-[#FFF8F0]/95 backdrop-blur px-5 pt-3 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2"><div className="w-9 h-9 rounded-xl bg-[#FF4D2E] grid place-items-center text-white font-black">P</div><div className="leading-none"><p className="font-black text-[16px]">Picky Eater</p><p className="text-[11px] text-[#7A6E66]">بيكي إيتر</p></div></div>
          <div className="flex items-center gap-2">
            <button onClick={()=>setLang(lang==="en"?"ar":"en")} className="flex items-center gap-1 bg-white border border-[#F0DDD3] px-3 py-2 rounded-full text-[13px] font-bold shadow-sm"><Globe size={14}/>{lang==="en"?"عربي":"EN"}</button>
            <button onClick={()=>setTab("profile")} className="w-9 h-9 rounded-full bg-[#1E1B18] text-white grid place-items-center font-bold text-[14px]">A</button>
          </div>
        </header>

        <main className="flex-1 px-5 pb-28">
          {tab==="home" && (
            <div className="fade-up">
              <h1 className="text-[28px] leading-[1.1] font-black">{lang==="ar"?"ماذا تريد أن تأكل اليوم؟":<>What do you<br/>want to eat today?</>}</h1>
              <p className="text-[#7A6E66] text-[14px] mt-1">{t.forYou} • {calorieGoal} {t.kcal} / {lang==="ar"?"يوم":"day"}</p>
              <div className="mt-4 flex items-center gap-2 bg-white rounded-full px-4 py-3 shadow-sm border border-[#F0DDD3]"><Search size={18} className="text-[#7A6E66] shrink-0"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={t.search} className="flex-1 outline-none text-[14px] bg-transparent min-w-0"/>{search && <button onClick={()=>setSearch("")} className="text-[#7A6E66]"><X size={16}/></button>}</div>
              <div className="flex gap-2 overflow-x-auto no-scrollbar py-4 -mx-5 px-5">
                {[{id:"all",label:t.all},...DIET_OPTS.map(d=>({id:d.id,label: lang==="ar"? d.ar:d.en}))].map(c=>(
                  <button key={c.id} onClick={()=>setDietFilter(c.id)} className={`shrink-0 px-4 py-2 rounded-full text-[13px] font-bold border ${dietFilter===c.id?"bg-[#1E1B18] text-white border-[#1E1B18]":"bg-white border-[#F0DDD3] text-[#4A423D]"}`}>{c.label}</button>
                ))}
              </div>
              {/* AI */}
              <div className="bg-[#1E1B18] text-white rounded-[24px] p-5 relative overflow-hidden">
                <div className="flex items-start justify-between gap-3"><div><div className="flex items-center gap-1.5 text-[#FFB23D] text-[12px] font-bold"><Sparkles size={14}/>{t.personalized}</div><h2 className="text-[20px] font-black mt-1 leading-tight">{t.aiTitle}</h2><p className="text-white/70 text-[13px] mt-1 leading-relaxed">{t.aiSub}</p></div><div className="w-11 h-11 rounded-2xl bg-[#FF4D2E] grid place-items-center shrink-0"><Sparkles size={20}/></div></div>
                {aiPicks ? <div className="mt-4 space-y-2">{aiPicks.map(id=>{const r=recipeById(id)!; return <button key={id} onClick={()=>openRecipe(id)} className="w-full bg-white/10 rounded-2xl p-3 flex gap-3 text-start items-center"><div className="w-11 h-11 rounded-xl grid place-items-center font-black text-white shrink-0" style={{background:r.grad}}>{r.letter}</div><div className="min-w-0"><p className="font-bold text-[14px] truncate">{lang==="ar"?r.nameAr:r.name}</p><p className="text-[12px] text-white/70 leading-snug">{aiReasons[id]}</p></div></button>})}</div> : <p className="text-white/60 text-[13px] mt-3">{t.aiHint}</p>}
                <button onClick={generateAI} className="mt-4 w-full bg-[#FF4D2E] py-3 rounded-full font-extrabold text-[14px]">{t.aiBtn}</button>
              </div>
              <div className="flex items-center justify-between mt-6 mb-3"><h2 className="font-black text-[18px]">{t.categories}</h2><span className="text-[13px] text-[#7A6E66]">{RECIPES.length} {t.recipes}</span></div>
              <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 -mx-5 px-5">
                {CATS.map(c=>(
                  <button key={c.id} onClick={()=>setCategory(c.id)} className={`shrink-0 px-4 py-2.5 rounded-2xl text-[13px] font-bold border ${category===c.id?"bg-[#FF4D2E] text-white border-[#FF4D2E]":"bg-white border-[#F0DDD3]"}`}>{lang==="ar"?c.ar:c.en}</button>
                ))}
              </div>
              <h2 className="font-black text-[18px] mt-5 mb-3">{t.allRecipes}</h2>
              <div className="grid grid-cols-2 gap-3">
                {filtered.map(r=>(
                  <article key={r.id} className="bg-white rounded-[24px] overflow-hidden shadow-sm border border-[#FFF0E8] flex flex-col">
                    <button onClick={()=>openRecipe(r.id)} className="text-start">
                      <div className="recipe-gradient h-[128px] grid place-items-center" style={{background:r.grad}}><span className="text-white font-black text-[42px] drop-shadow relative z-10">{r.letter}</span><span className="absolute top-3 start-3 bg-white/90 px-2.5 py-1 rounded-full text-[11px] font-bold text-[#1E1B18]">{lang==="ar"?r.categoryAr:r.category}</span><span className="absolute bottom-3 end-3 bg-black/25 text-white px-2 py-1 rounded-full text-[11px] font-bold flex items-center gap-1"><Star size={11} className="fill-white"/>{r.rating}</span></div>
                      <div className="p-3"><h3 className="font-extrabold text-[15px] leading-tight min-h-[40px]">{lang==="ar"?r.nameAr:r.name}</h3><p className="text-[12px] text-[#7A6E66] mt-1 line-clamp-2 leading-relaxed">{lang==="ar"?r.descAr:r.desc}</p><div className="flex items-center gap-2 mt-2 text-[11px] font-bold text-[#5A504A]"><span className="flex items-center gap-1"><Clock size={12}/>{r.time} {t.min}</span><span className="flex items-center gap-1"><Flame size={12} className="text-[#FF4D2E]"/>{r.calories}</span><span className="bg-[#E4F6EC] text-[#1F7A4A] px-2 py-0.5 rounded-full">{lang==="ar"?r.difficultyAr:r.difficulty}</span></div></div>
                    </button>
                    <div className="px-3 pb-3 mt-auto flex justify-between items-center"><button onClick={()=>toggleFav(r.id)} aria-label="Favorite" className={`w-9 h-9 rounded-full grid place-items-center border ${favorites.includes(r.id)?"bg-[#FFE6DE] border-[#FFD0C2] text-[#FF4D2E]":"bg-white border-[#F0DDD3] text-[#7A6E66]"}`}><Heart size={17} className={favorites.includes(r.id)?"fill-[#FF4D2E]":""}/></button><button onClick={()=>openRecipe(r.id)} className="text-[12px] font-extrabold bg-[#FFF0E8] text-[#FF4D2E] px-3 py-2 rounded-full">{lang==="ar"?"عرض الوصفة":"View recipe"}</button></div>
                  </article>
                ))}
              </div>
              {filtered.length===0 && <div className="bg-white rounded-[24px] p-6 text-center mt-2"><p className="font-bold">{t.searchNo}</p><button onClick={()=>{setSearch("");setDietFilter("all");setCategory("All");}} className="mt-3 bg-[#1E1B18] text-white px-4 py-2 rounded-full text-[13px] font-bold">{lang==="ar"?"مسح الفلاتر":"Clear filters"}</button></div>}
            </div>
          )}

          {tab==="planner" && (
            <div className="fade-up">
              <div className="flex items-start justify-between"><div><h1 className="text-[26px] font-black leading-tight">{t.planTitle}</h1><p className="text-[#7A6E66] text-[13px] mt-1">{t.weekPlan} • {Object.keys(planner).length} {lang==="ar"?"وجبة":"meals"}</p></div><button onClick={()=>{setPlanner({}); showToast(t.clearWeek);}} className="text-[12px] font-bold bg-white border border-[#F0DDD3] px-3 py-2 rounded-full shrink-0">{t.clearWeek}</button></div>
              <div className="flex gap-2 overflow-x-auto no-scrollbar py-4 -mx-5 px-5">{days.map((d,i)=>(<button key={d} onClick={()=>setPlannerDayIdx(i)} className={`shrink-0 w-[62px] py-3 rounded-2xl text-center border ${plannerDayIdx===i?"bg-[#1E1B18] text-white border-[#1E1B18]":"bg-white border-[#F0DDD3]"}`}><span className="block text-[12px] font-bold">{d}</span><span className="block text-[11px] opacity-70 mt-0.5">{lang==="ar"?"اليوم":"Day"} {i+1}</span></button>))}</div>
              <div className="bg-[#1F9D5E] text-white rounded-[20px] p-4 flex justify-between items-center"><div><p className="text-[12px] opacity-80">{days[plannerDayIdx]} • {t.dayCal}</p><p className="text-[22px] font-black">{dayCalories(plannerDayIdx)} {t.kcal}</p></div><div className="bg-white/20 px-3 py-2 rounded-full text-[12px] font-bold">{lang==="ar"?"الهدف":"Goal"} {calorieGoal}</div></div>
              <div className="space-y-3 mt-4">{slots.map(s=>{
                const key=`${plannerDayIdx}-${s.id}`; const rid=planner[key]; const r=rid?recipeById(rid):undefined;
                return <div key={s.id} className="bg-white rounded-[24px] p-3 border border-[#FFF0E8] shadow-sm flex gap-3 items-center">{r? <><div className="w-[68px] h-[68px] rounded-2xl grid place-items-center text-white font-black text-[22px] shrink-0" style={{background:r.grad}}>{r.letter}</div><div className="flex-1 min-w-0"><p className="text-[11px] font-bold text-[#FF4D2E] uppercase tracking-wide">{s.label}</p><p className="font-extrabold leading-tight truncate">{lang==="ar"?r.nameAr:r.name}</p><p className="text-[12px] text-[#7A6E66]">{r.calories} {t.kcal} • {r.time} {t.min} • ★ {r.rating}</p></div><button onClick={()=>openRecipe(r.id)} className="bg-[#FFF0E8] text-[#FF4D2E] px-3 py-2 rounded-full text-[12px] font-bold shrink-0">{lang==="ar"?"عرض":"View"}</button><button onClick={()=>setPlanner(prev=>{const n={...prev}; delete n[key]; return n;})} aria-label="Remove" className="w-9 h-9 rounded-full bg-[#FFF0E8] grid place-items-center text-[#7A6E66] shrink-0"><Trash2 size={16}/></button></> : <><div className="w-[68px] h-[68px] rounded-2xl bg-[#FFF0E8] grid place-items-center text-[#FF4D2E] shrink-0"><Plus size={22}/></div><div className="flex-1"><p className="text-[11px] font-bold text-[#FF4D2E] uppercase">{s.label}</p><p className="font-bold text-[14px]">{t.emptyPlanner}</p><p className="text-[12px] text-[#7A6E66]">{t.tapToAdd}</p></div><button onClick={()=>setPickerSlot(key)} className="bg-[#1E1B18] text-white px-4 py-2.5 rounded-full text-[12px] font-bold shrink-0">{t.add}</button></>}</div>
              })}</div>
              <div className="bg-white rounded-[24px] p-4 mt-4"><p className="font-extrabold flex items-center gap-2"><ChefHat size={18} className="text-[#FF4D2E]"/>{lang==="ar"?"وصفات سريعة لهذا اليوم":"Quick picks for today"}</p><div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar">{RECIPES.filter(r=>r.time<=20).map(r=>(<button key={r.id} onClick={()=>openRecipe(r.id)} className="shrink-0 w-[150px] text-start bg-[#FFF8F0] rounded-2xl p-3 border border-[#F0DDD3]"><span className="block w-8 h-8 rounded-lg grid place-items-center text-white font-black" style={{background:r.grad}}>{r.letter}</span><span className="block font-bold text-[13px] mt-2 leading-tight">{lang==="ar"?r.nameAr:r.name}</span><span className="text-[11px] text-[#7A6E66]">{r.time} {t.min}</span></button>))}</div></div>
            </div>
          )}

          {tab==="shopping" && (
            <div className="fade-up">
              <h1 className="text-[26px] font-black">{t.shopTitle}</h1><p className="text-[#7A6E66] text-[13px] mt-1">{shopping.length} {t.items} • {checkedCount} {t.checked}</p>
              <div className="bg-white rounded-[24px] p-4 mt-4 shadow-sm border border-[#FFF0E8]"><p className="font-extrabold">{t.addCustom}</p><div className="flex gap-2 mt-3"><input value={customName} onChange={e=>setCustomName(e.target.value)} placeholder={t.itemName} className="flex-1 min-w-0 bg-[#FFF8F0] border border-[#F0DDD3] rounded-full px-4 py-2.5 outline-none text-[14px]"/><select value={customCat} onChange={e=>setCustomCat(e.target.value)} className="bg-[#FFF8F0] border border-[#F0DDD3] rounded-full px-2 py-2.5 text-[13px] font-bold"><option>Produce</option><option>Pantry</option><option>Dairy</option><option>Protein</option></select></div><button onClick={()=>{ if(!customName.trim()){showToast(t.needName); return;} setShopping(prev=>[...prev,{id:`custom-${Date.now()}`,name:customName.trim(),nameAr:customName.trim(),qty:1,unit:"pc",cat:customCat,checked:false}]); setCustomName(""); showToast(t.addedShop);}} className="mt-3 w-full bg-[#FF4D2E] text-white py-3 rounded-full font-extrabold text-[14px]">{t.add}</button></div>
              {shopping.length===0 ? <div className="bg-white rounded-[24px] p-8 text-center mt-4"><ShoppingBasket className="mx-auto text-[#FF4D2E]" size={32}/><p className="font-extrabold mt-3">{t.emptyShop}</p><p className="text-[13px] text-[#7A6E66] mt-1">{t.emptyShopSub}</p><button onClick={()=>setTab("home")} className="mt-4 bg-[#1E1B18] text-white px-5 py-2.5 rounded-full text-[13px] font-bold">{lang==="ar"?"تصفح الوصفات":"Browse recipes"}</button></div> : <>
                <div className="flex justify-end mt-4"><button onClick={()=>setShopping(prev=>prev.filter(i=>!i.checked))} className="text-[12px] font-bold bg-white border border-[#F0DDD3] px-3 py-2 rounded-full">{t.clearChecked}</button></div>
                <div className="space-y-4 mt-3">{Object.entries(groupedShopping).map(([cat,items])=>(<div key={cat} className="bg-white rounded-[24px] p-4 border border-[#FFF0E8]"><p className="font-extrabold flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[#FF4D2E]"/>{cat==="Produce"?t.produce:cat==="Pantry"?t.pantry:cat==="Dairy"?t.dairy:cat==="Protein"?t.proteinCat:t.other} <span className="text-[12px] text-[#7A6E66] font-normal">({items.length})</span></p><div className="divide-y divide-[#FFF0E8] mt-1">{items.map(it=>(<div key={it.id} className="py-3 flex items-center gap-3"><button onClick={()=>setShopping(prev=>prev.map(x=>x.id===it.id?{...x,checked:!x.checked}:x))} aria-label="Check" className={`w-6 h-6 rounded-full grid place-items-center border-2 shrink-0 ${it.checked?"bg-[#1F9D5E] border-[#1F9D5E] text-white":"border-[#E8D9CF] text-transparent"}`}><Check size={14}/></button><div className="flex-1 min-w-0"><p className={`font-bold text-[14px] truncate ${it.checked?"line-through text-[#9A8F88]":""}`}>{lang==="ar"?it.nameAr:it.name}</p><p className="text-[12px] text-[#7A6E66]">{cat}</p></div><div className="flex items-center gap-1 shrink-0"><button onClick={()=>setShopping(prev=>prev.map(x=>x.id===it.id?{...x,qty:Math.max(0.5,x.qty-1)}:x))} className="w-7 h-7 rounded-full bg-[#FFF0E8] grid place-items-center"><Minus size={13}/></button><span className="w-10 text-center text-[13px] font-bold">{it.qty} {it.unit}</span><button onClick={()=>setShopping(prev=>prev.map(x=>x.id===it.id?{...x,qty:x.qty+1}:x))} className="w-7 h-7 rounded-full bg-[#FFF0E8] grid place-items-center"><Plus size={13}/></button><button onClick={()=>setShopping(prev=>prev.filter(x=>x.id!==it.id))} aria-label="Delete" className="w-7 h-7 rounded-full grid place-items-center text-[#9A8F88]"><Trash2 size={15}/></button></div></div>))}</div></div>))}</div>
              </>}
            </div>
          )}

          {tab==="favorites" && (
            <div className="fade-up"><h1 className="text-[26px] font-black">{t.favorites}</h1><p className="text-[#7A6E66] text-[13px] mt-1">{favorites.length} {lang==="ar"?"وصفة محفوظة":"saved recipes"}</p>
              {favorites.length===0 ? <div className="bg-white rounded-[28px] p-8 text-center mt-5"><div className="w-16 h-16 rounded-full bg-[#FFE6DE] grid place-items-center mx-auto text-[#FF4D2E]"><Heart size={28}/></div><p className="font-extrabold mt-4 text-[18px]">{t.favEmpty}</p><p className="text-[13px] text-[#7A6E66] mt-1">{t.favEmptySub}</p><button onClick={()=>setTab("home")} className="mt-4 bg-[#FF4D2E] text-white px-5 py-3 rounded-full font-bold text-[14px]">{lang==="ar"?"اكتشف الوصفات":"Discover recipes"}</button></div> :
              <div className="grid grid-cols-2 gap-3 mt-4">{favorites.map(id=>{const r=recipeById(id); if(!r) return null; return <article key={id} className="bg-white rounded-[24px] overflow-hidden border border-[#FFF0E8]"><button onClick={()=>openRecipe(id)} className="text-start w-full"><div className="h-[110px] grid place-items-center text-white font-black text-[36px]" style={{background:r.grad}}>{r.letter}</div><div className="p-3"><p className="font-extrabold text-[14px] leading-tight min-h-[36px]">{lang==="ar"?r.nameAr:r.name}</p><p className="text-[12px] text-[#7A6E66] mt-1">{r.calories} {t.kcal} • {r.time} {t.min}</p></div></button><button onClick={()=>toggleFav(id)} className="mx-3 mb-3 flex items-center gap-1.5 text-[12px] font-bold text-[#FF4D2E] bg-[#FFE6DE] px-3 py-2 rounded-full"><Heart size={13} className="fill-[#FF4D2E]"/>{t.remove}</button></article>})}</div>}
            </div>
          )}

          {tab==="profile" && (
            <div className="fade-up">
              <div className="bg-[#1E1B18] text-white rounded-[24px] p-5 flex items-center gap-3"><div className="w-14 h-14 rounded-full bg-[#FF4D2E] grid place-items-center text-[22px] font-black">A</div><div><p className="font-black text-[18px]">Ahlan, Food Lover</p><p className="text-white/70 text-[13px]">{t.profileSub}</p></div></div>
              <div className="bg-white rounded-[24px] p-5 mt-4 border border-[#FFF0E8]"><div className="flex justify-between items-center"><p className="font-extrabold flex items-center gap-2"><Globe size={17} className="text-[#FF4D2E]"/>{t.language}</p><div className="flex bg-[#FFF0E8] rounded-full p-1"><button onClick={()=>setLang("en")} className={`px-4 py-2 rounded-full text-[13px] font-bold ${lang==="en"?"bg-white shadow-sm":""}`}>English</button><button onClick={()=>setLang("ar")} className={`px-4 py-2 rounded-full text-[13px] font-bold ${lang==="ar"?"bg-white shadow-sm":""}`}>العربية</button></div></div><p className="text-[12px] text-[#7A6E66] mt-2">{t.saveNote} {loaded? `• ${saveNote||t.saved}`: t.loading}</p></div>
              <div className="bg-white rounded-[24px] p-5 mt-4 border border-[#FFF0E8]"><p className="font-extrabold flex items-center gap-2"><Leaf size={17} className="text-[#1F9D5E]"/>{t.prefs}</p><div className="space-y-2 mt-4">{DIET_OPTS.map(d=>{const on=dietary.includes(d.id); return <button key={d.id} onClick={()=>toggleList(dietary,d.id,setDietary)} className="w-full flex items-center justify-between bg-[#FFF8F0] rounded-2xl px-4 py-3"><span className="font-bold text-[14px]">{lang==="ar"?d.ar:d.en}</span><span className={`w-11 h-6 rounded-full relative transition ${on?"bg-[#1F9D5E]":"bg-[#E8D9CF]"}`}><span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow ${on?"end-0.5":"start-0.5"}`}/></span></button>})}</div></div>
              <div className="bg-white rounded-[24px] p-5 mt-4 border border-[#FFF0E8]"><p className="font-extrabold flex items-center gap-2"><ShieldCheck size={17} className="text-[#FF4D2E]"/>{t.allergies}</p><div className="flex flex-wrap gap-2 mt-3">{ALLERGY_OPTS.map(a=>{const on=allergies.includes(a.id); return <button key={a.id} onClick={()=>toggleList(allergies,a.id,setAllergies)} className={`px-4 py-2.5 rounded-full text-[13px] font-bold border ${on?"bg-[#FF4D2E] text-white border-[#FF4D2E]":"bg-white border-[#F0DDD3]"}`}>{lang==="ar"?a.ar:a.en}</button>})}</div></div>
              <div className="bg-white rounded-[24px] p-5 mt-4 border border-[#FFF0E8]"><p className="font-extrabold">{t.disliked}</p><div className="flex gap-2 mt-3"><input value={newDisliked} onChange={e=>setNewDisliked(e.target.value)} onKeyDown={e=>{if(e.key==="Enter" && newDisliked.trim()){setDisliked([...disliked,newDisliked.trim().toLowerCase()]); setNewDisliked("");}}} placeholder={lang==="ar"?"مثال: فطر":"e.g. mushrooms"} className="flex-1 min-w-0 bg-[#FFF8F0] border border-[#F0DDD3] rounded-full px-4 py-2.5 outline-none text-[14px]"/><button onClick={()=>{if(newDisliked.trim()){setDisliked([...disliked,newDisliked.trim().toLowerCase()]); setNewDisliked("");}}} className="bg-[#1E1B18] text-white px-4 py-2.5 rounded-full font-bold text-[13px]">{t.add}</button></div><div className="flex flex-wrap gap-2 mt-3">{disliked.map(d=>(<span key={d} className="bg-[#FFE6DE] text-[#A83A1E] px-3 py-1.5 rounded-full text-[12px] font-bold flex items-center gap-1">{d}<button onClick={()=>setDisliked(disliked.filter(x=>x!==d))}><X size={13}/></button></span>))}{disliked.length===0 && <span className="text-[13px] text-[#7A6E66]">{lang==="ar"?"لا توجد مكونات مستبعدة.":"No disliked ingredients yet."}</span>}</div></div>
              <div className="bg-white rounded-[24px] p-5 mt-4 border border-[#FFF0E8]"><div className="flex justify-between items-center"><p className="font-extrabold flex items-center gap-2"><SlidersHorizontal size={17} className="text-[#FF4D2E]"/>{t.calorieGoal}</p><span className="bg-[#FFF0E8] text-[#FF4D2E] px-3 py-1 rounded-full font-black text-[14px]">{calorieGoal} {t.kcal}</span></div><input type="range" min={1200} max={3500} step={50} value={calorieGoal} onChange={e=>setCalorieGoal(Number(e.target.value))} className="w-full mt-4 accent-[#FF4D2E]"/><div className="flex justify-between text-[11px] text-[#7A6E66]"><span>1200</span><span>2350</span><span>3500</span></div><p className="text-[12px] text-[#7A6E66] mt-2">{lang==="ar"?"يُستخدم لتخصيص اقتراحات الذكاء الاصطناعي.":"Used to personalize your AI suggestions."}</p></div>
            </div>
          )}
        </main>

        {/* BOTTOM NAV */}
        <nav className="sticky bottom-0 z-30 bg-white/95 backdrop-blur border-t border-[#F0DDD3] px-3 pt-2 pb-4 flex justify-between">
          {[{id:"home",label:t.home,icon:<Home size={20}/>},{id:"planner",label:t.planner,icon:<CalendarDays size={20}/>},{id:"shopping",label:t.shopping,icon:<ShoppingBasket size={20}/>},{id:"favorites",label:t.favorites,icon:<Heart size={20}/>},{id:"profile",label:t.profile,icon:<User size={20}/> }].map(n=>(
            <button key={n.id} onClick={()=>setTab(n.id)} className={`flex-1 flex flex-col items-center gap-0.5 py-1.5 rounded-2xl ${tab===n.id?"text-[#FF4D2E] bg-[#FFF0E8]":"text-[#8A7E77]"}`}>{n.icon}<span className="text-[11px] font-bold">{n.label}</span>{n.id==="shopping" && shopping.length>0 && <span className="absolute -mt-1 ms-8 bg-[#FF4D2E] text-white text-[10px] w-4 h-4 rounded-full grid place-items-center">{shopping.length}</span>}</button>
          ))}
        </nav>

        {/* PICKER MODAL */}
        {pickerSlot && (
          <div className="absolute inset-0 z-50 bg-black/40 flex items-end justify-center p-0">
            <div className="bg-white w-full rounded-t-[28px] p-5 pop max-h-[80vh] overflow-y-auto"><div className="flex justify-between items-center"><h3 className="font-black text-[18px]">{t.pickRecipe}</h3><button onClick={()=>setPickerSlot(null)} className="w-9 h-9 rounded-full bg-[#FFF0E8] grid place-items-center"><X size={17}/></button></div><p className="text-[13px] text-[#7A6E66] mt-1">{days[Number(pickerSlot.split("-")[0])]} • {slots.find(s=>s.id===pickerSlot.split("-")[1])?.label}</p>
              <div className="space-y-2 mt-4">{RECIPES.map(r=>(<button key={r.id} onClick={()=>{ addToPlanner(r.id, Number(pickerSlot.split("-")[0]), pickerSlot.split("-")[1]); setPickerSlot(null); }} className="w-full flex gap-3 items-center bg-[#FFF8F0] rounded-2xl p-3 text-start"><span className="w-12 h-12 rounded-xl grid place-items-center text-white font-black shrink-0" style={{background:r.grad}}>{r.letter}</span><span className="flex-1 min-w-0"><span className="block font-bold text-[14px] truncate">{lang==="ar"?r.nameAr:r.name}</span><span className="text-[12px] text-[#7A6E66]">{r.calories} {t.kcal} • {r.time} {t.min}</span></span><Plus size={18} className="text-[#FF4D2E]"/></button>))}</div>
            </div>
          </div>
        )}

        {/* RECIPE DETAIL */}
        {selected && (
          <div className="absolute inset-0 z-40 bg-[#FFF8F0] overflow-y-auto pop">
            <div className="sticky top-0 z-10 bg-[#FFF8F0]/95 backdrop-blur px-4 py-3 flex justify-between items-center"><button onClick={()=>setSelectedId(null)} className="flex items-center gap-1 font-bold text-[14px] bg-white border border-[#F0DDD3] px-3 py-2 rounded-full"><ChevronLeft size={16}/>{t.back}</button><button onClick={()=>toggleFav(selected.id)} aria-label="Favorite" className={`w-10 h-10 rounded-full grid place-items-center ${favorites.includes(selected.id)?"bg-[#FFE6DE] text-[#FF4D2E]":"bg-white border border-[#F0DDD3]"}`}><Heart size={19} className={favorites.includes(selected.id)?"fill-[#FF4D2E]":""}/></button></div>
            <div className="px-5 pb-10">
              <div className="h-[210px] rounded-[28px] grid place-items-center relative overflow-hidden" style={{background:selected.grad}}><span className="text-white font-black text-[96px] drop-shadow">{selected.letter}</span><span className="absolute bottom-4 start-4 bg-white/90 px-3 py-1.5 rounded-full text-[12px] font-bold">{lang==="ar"?selected.categoryAr:selected.category}</span><span className="absolute top-4 end-4 bg-black/25 text-white px-3 py-1.5 rounded-full text-[12px] font-bold flex items-center gap-1"><Star size={12} className="fill-white"/>{selected.rating} ({selected.reviews})</span></div>
              <h2 className="text-[28px] font-black leading-tight mt-4">{lang==="ar"?selected.nameAr:selected.name}</h2><p className="text-[#7A6E66] text-[14px] leading-relaxed mt-1">{lang==="ar"?selected.descAr:selected.desc}</p>
              <div className="grid grid-cols-4 gap-2 mt-4">{[{label:t.time,val:`${selected.time} ${t.min}`,icon:<Clock size={15}/>},{label:t.calories,val:`${selected.calories}`,icon:<Flame size={15}/>},{label:t.difficulty,val:lang==="ar"?selected.difficultyAr:selected.difficulty,icon:<ChefHat size={15}/>},{label:t.rating,val:`${selected.rating}`,icon:<Star size={15}/> }].map((s,i)=>(<div key={i} className="bg-white rounded-2xl p-2.5 text-center border border-[#FFF0E8]"><span className="flex justify-center text-[#FF4D2E]">{s.icon}</span><p className="font-extrabold text-[13px] mt-1 leading-tight">{s.val}</p><p className="text-[11px] text-[#7A6E66]">{s.label}</p></div>))}</div>
              <div className="bg-white rounded-[24px] p-4 mt-4 flex justify-between items-center border border-[#FFF0E8]"><div><p className="font-extrabold">{t.servings}</p><p className="text-[12px] text-[#7A6E66]">{lang==="ar"?"تتغير الكميات تلقائياً":"Quantities update automatically"}</p></div><div className="flex items-center gap-2"><button onClick={()=>setServings(Math.max(1,servings-1))} className="w-9 h-9 rounded-full bg-[#FFF0E8] grid place-items-center"><Minus size={16}/></button><span className="font-black text-[18px] w-6 text-center">{servings}</span><button onClick={()=>setServings(servings+1)} className="w-9 h-9 rounded-full bg-[#1E1B18] text-white grid place-items-center"><Plus size={16}/></button></div></div>
              <h3 className="font-black text-[18px] mt-5 flex items-center gap-2"><BookOpen size={18} className="text-[#FF4D2E]"/>{t.ingredients}</h3>
              <div className="bg-white rounded-[24px] p-2 mt-3 divide-y divide-[#FFF0E8] border border-[#FFF0E8]">{selected.ingredients.map((ing,i)=>{ const scaled = Math.round(ing.qty*servings/selected.servings*10)/10; return <div key={i} className="flex justify-between items-center py-3 px-3"><span className="flex items-center gap-2 font-bold text-[14px]"><span className="w-2 h-2 rounded-full bg-[#1F9D5E]"/>{lang==="ar"?ing.nameAr:ing.name}</span><span className="text-[13px] font-bold text-[#7A6E66]">{scaled} {lang==="ar"?ing.unitAr:ing.unit}</span></div>})}</div>
              <h3 className="font-black text-[18px] mt-5">{t.steps}</h3><div className="space-y-3 mt-3">{(lang==="ar"?selected.stepsAr:selected.steps).map((s,i)=>(<div key={i} className="bg-white rounded-2xl p-4 flex gap-3 border border-[#FFF0E8]"><span className="w-7 h-7 rounded-full bg-[#FF4D2E] text-white grid place-items-center font-black text-[13px] shrink-0">{i+1}</span><p className="text-[14px] leading-relaxed">{s}</p></div>))}</div>
              <h3 className="font-black text-[18px] mt-5">{t.nutrition} <span className="text-[13px] text-[#7A6E66] font-normal">{t.perServing}</span></h3>
              <div className="grid grid-cols-3 gap-2 mt-3">{[{label:t.protein,val:`${selected.protein}g`},{label:t.carbs,val:`${selected.carbs}g`},{label:t.fat,val:`${selected.fat}g`}].map((n,i)=>(<div key={i} className="bg-white rounded-2xl p-4 text-center border border-[#FFF0E8]"><p className="font-black text-[18px]">{n.val}</p><p className="text-[12px] text-[#7A6E66]">{n.label}</p></div>))}</div>
              <div className="flex flex-wrap gap-2 mt-4">{selected.tags.map(tag=>{ const d=DIET_OPTS.find(x=>x.id===tag); return <span key={tag} className="bg-[#E4F6EC] text-[#1F7A4A] px-3 py-1.5 rounded-full text-[12px] font-bold">{lang==="ar"?d?.ar||tag:tag}</span>})}</div>
              <button onClick={()=>addToShopping(selected,servings)} className="mt-6 w-full bg-[#FF4D2E] text-white py-4 rounded-full font-extrabold flex items-center justify-center gap-2"><ShoppingBag size={18}/>{t.addShop}</button>
              <button onClick={()=>setDetailPlannerOpen(true)} className="mt-3 w-full bg-[#1E1B18] text-white py-4 rounded-full font-extrabold flex items-center justify-center gap-2"><CalendarDays size={18}/>{t.addPlan}</button>
            </div>
            {detailPlannerOpen && (
              <div className="absolute inset-0 bg-black/40 flex items-end justify-center"><div className="bg-white w-full rounded-t-[28px] p-5 pop"><div className="flex justify-between items-center"><h3 className="font-black">{t.chooseDay}</h3><button onClick={()=>setDetailPlannerOpen(false)} className="w-9 h-9 rounded-full bg-[#FFF0E8] grid place-items-center"><X size={16}/></button></div><p className="text-[13px] text-[#7A6E66] mt-1">{lang==="ar"?selected.nameAr:selected.name}</p><div className="flex gap-2 overflow-x-auto no-scrollbar py-3">{days.map((d,i)=>(<button key={d} onClick={()=>setDetailDay(i)} className={`shrink-0 px-4 py-2.5 rounded-full text-[13px] font-bold border ${detailDay===i?"bg-[#1E1B18] text-white":"bg-white border-[#F0DDD3]"}`}>{d}</button>))}</div><div className="flex gap-2">{slots.map(s=>(<button key={s.id} onClick={()=>setDetailSlot(s.id)} className={`flex-1 py-3 rounded-full text-[13px] font-bold border ${detailSlot===s.id?"bg-[#FF4D2E] text-white border-[#FF4D2E]":"bg-white border-[#F0DDD3]"}`}>{s.label}</button>))}</div><button onClick={()=>{addToPlanner(selected.id,detailDay,detailSlot); setDetailPlannerOpen(false);}} className="mt-4 w-full bg-[#FF4D2E] text-white py-3.5 rounded-full font-extrabold">{t.addPlan}</button></div></div>
            )}
          </div>
        )}

        {toast && <div className="absolute bottom-24 start-1/2 -translate-x-1/2 z-[60] bg-[#1E1B18] text-white px-4 py-2.5 rounded-full text-[13px] font-bold flex items-center gap-2 shadow-xl whitespace-nowrap"><CircleCheck size={16} className="text-[#7EDFA8]"/>{toast}</div>}
      </div>
    </div>
  );
}
